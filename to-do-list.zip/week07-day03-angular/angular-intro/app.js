console.log('app.js: angular:', angular );

angular.module('myFirstApp', []);
